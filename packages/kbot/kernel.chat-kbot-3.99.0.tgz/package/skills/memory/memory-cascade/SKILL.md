---
name: memory-cascade
description: Use when memory feels slow, bloated, or is contradicting itself. The 5-tier cascade has rules about what gets promoted, demoted, or forgotten — follow them or memory decays into noise.
version: 1.0.0
author: kbot
license: MIT
metadata:
  kbot:
    tags: [memory, cascade, reflection, consolidation]
    related_skills: [dream-to-commit, autopoiesis-loop]
---

# Memory Cascade

kbot's memory is not one store — it's five tiers that flow into each other like a karst system. Working memory fills, overflows into short-term, which consolidates into long-term, which distills into reflections, which collapse into meta-reflections. Each tier has different rules.

## The Five Tiers

| Tier | Location | Retention | Promotion Rule |
|---|---|---|---|
| 1. Working | in-process `Map<sessionId, history>` | lifetime of the session | auto-flushes to short-term on session close |
| 2. Short-term | `~/.kbot/memory/short-term/*.jsonl` | 7 days rolling | entries tagged `important` promote to long-term |
| 3. Long-term | `~/.kbot/memory/long-term/*.md` | indefinite | distilled into reflections nightly |
| 4. Reflections | `~/.kbot/memory/reflections/*.md` | indefinite | aggregated into meta-reflections weekly |
| 5. Meta-reflections | `~/.kbot/memory/meta/*.md` | indefinite | immutable signal into every prompt |

## Iron Law

```
PROMOTION IS EARNED. DEMOTION IS AUTOMATIC. DELETION IS NEVER MANUAL.
```

Manually deleting memory entries breaks the cascade invariants — the reflection engine still sees dangling references. If a memory is wrong, *correct it* with a new entry pointing at the old one; don't delete.

## When to Force a Promotion

- The user says "remember this" — explicit flag, auto-promotes to long-term.
- A correction was issued — auto-promotes with tag `correction` (loaded into every future prompt).
- A project fact that decays in 30+ days — promote to long-term manually via `memory_save`.

## When to Let It Demote Naturally

- Session chatter, one-off context, successful completions — leave in working/short-term, let them fall out.
- Debug state, test run output — these should not be in memory at all; filter at write time.

## Reading the Cascade

`getSynthesisContext(n)` loads the top-n meta-reflections into every prompt automatically. You don't need to fetch lower tiers in normal work — the cascade surfaces what's relevant. Dig into lower tiers only when:
- You're investigating a contradiction in advice.
- You're debugging why kbot "forgot" something.
- You're curating teacher traces (where low-tier detail matters).

## Anti-Pattern

Treating memory as a notes app. If you find yourself writing `memory_save` for every session summary, you're duplicating what the dream engine does automatically. Reserve explicit saves for facts kbot *would not learn on its own* (user preferences, project constraints, non-obvious decisions).

## What Emerges

After ~30 days, meta-reflections stabilize into a compressed profile of how the user works. That profile loads into every session's prompt as ambient context. The subjective experience: kbot starts "already knowing you" by session 20-ish.
