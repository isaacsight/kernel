---
name: dream-to-commit
description: Use in the first session of the day. The dream engine ran overnight and left a digest — open it first, it tells you what past-you already figured out.
version: 1.0.0
author: kbot
license: MIT
metadata:
  kbot:
    tags: [dream, memory, morning-routine, consolidation]
    related_skills: [autopoiesis-loop, memory-cascade]
---

# Dream to Commit

Between sessions, the dream engine consolidates transcripts into reflections. In the morning, those reflections contain answers to questions you were about to ask — and sometimes fixes to bugs you haven't logged yet.

## Iron Law

```
DO NOT START MORNING WORK WITHOUT READING LAST NIGHT'S DREAMS.
```

## The Morning Protocol

1. `kbot dream status` — confirms the engine ran.
2. `kbot dream journal --since yesterday` — reads new reflection entries. They cluster by theme.
3. For each reflection tagged `actionable`, either:
   - Open a commit that captures the fix / improvement kbot spotted, or
   - Write a memory note explaining why *not* to act on it.
4. Only after the journal is reviewed, start new work.

## Why This Works

The dream engine cross-references: yesterday's tool errors, uncommitted diffs, SCRATCHPAD drift, learned-router misses, and daemon reports. It has more signal than a human going through the same inputs because nothing gets forgotten between windows.

## What You'll See Over Time

- **Week 1**: generic reflections ("this function was modified often").
- **Week 3**: specific forecasts ("this pattern fails on Linux — consider a platform guard").
- **Week 8**: cross-project insights ("you re-implemented X in three repos — extract into a shared package").

The quality compounds because reflections feed the reflection engine itself (three-tier memory: events → reflections → meta-reflections).

## Anti-Pattern

Ignoring the journal because "it's just the AI talking to itself." The journal is the only durable artifact of every session's learning. Ignoring it makes the dream engine pure cost with no dividend.

## Integration

- `synthesis_engine.getSynthesisContext(8)` reads the top 8 reflections into every new agent prompt automatically.
- `corrections` loader pulls any reflection tagged `correction` into the active system prompt as a closed-loop signal.
- The skills loader scores skills partly on overlap with recent reflection themes — yesterday's dreams bias today's relevance.
